ROUND 2 - ANALOG CTF
Read Round2_handbook.pdf first (rules, flag format, how to feed files into LTspice, Audacity basics).
Each folder in challenges/ is one challenge: open its README.txt for the story and the task.
Unzip everything, and open each LTspice template from inside its own folder (the input files must sit next to it).
For every circuit challenge, upload the LTspice file (.asc) you used together with the flag. A flag without its .asc gets no points.
