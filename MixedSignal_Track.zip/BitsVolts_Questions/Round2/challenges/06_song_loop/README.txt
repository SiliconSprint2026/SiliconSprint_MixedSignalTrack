SONG LOOP   (300 points)   needs: your Q5 chain (Q4 ADC part + Q2 DAC)

A track was smuggled out with a message inside. The message only shows after the song is digitised 8000 times a second and rebuilt.

WHAT TO DO
Open song_loop_template.asc. Put your ADC part in box 1 and your DAC in box 2. Run it and open song_out.wav in Audacity in Spectrogram view. Flag = BV{the text you see} using capital letters and digits.

FILES
  song.wav
  song_loop_template.asc

Flags look like BV{...}. Capital and small letters both count as correct.
Submit the flag on the portal AND upload the LTspice file (.asc) you used, named TeamID_song_loop.asc, on the Round 2 upload form. A flag without your .asc, or one your .asc cannot produce, gets no points.
Unzip the whole folder first and open the template from the unzipped folder. Running the empty template gives a "No such node" error: put your circuit in first.
