LOOK CLOSER   (50 points)   needs: Audacity only

A radio station keeps broadcasting this hiss. The engineer swears there is a message in it.

WHAT TO DO
Find the message hidden in hiss.wav. The whole flag is in there, brackets included.

FILES
  hiss.wav

Flags look like BV{...}. Capital and small letters both count as correct.
Submit the flag on the portal.
