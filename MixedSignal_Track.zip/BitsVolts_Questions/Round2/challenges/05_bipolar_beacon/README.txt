BIPOLAR BEACON   (200 points)   needs: your Q2 DAC

A lighthouse keeps its message as raw six-bit numbers: 8000 of them per second. Turn them back into a signal.

WHAT TO DO
Open beacon_template.asc and put your Q2 DAC in the box. Run it and open beacon_out.wav in Audacity. Flag = BV{what the beacon sends} using capital letters and digits with no spaces.

FILES
  b0.txt
  b1.txt
  b2.txt
  b3.txt
  b4.txt
  b5.txt
  beacon_template.asc

Flags look like BV{...}. Capital and small letters both count as correct.
Submit the flag on the portal AND upload the LTspice file (.asc) you used, named TeamID_beacon.asc, on the Round 2 upload form. A flag without your .asc, or one your .asc cannot produce, gets no points.
Unzip the whole folder first and open the template from the unzipped folder. Running the empty template gives a "No such node" error: put your circuit in first.
