OCTAL METER   (150 points)   needs: your Q3 flash ADC (main circuit)

A sensor reports its readings as a voltage that changes once per millisecond. Only an 8-level meter can read it.

WHAT TO DO
Open octal_meter_template.asc and put your Q3 ADC in the box. Every millisecond gives one digit from 0 to 7. Turn the digits into text. The whole flag is sent, brackets included.

FILES
  meter.txt
  octal_meter_template.asc

Flags look like BV{...}. Capital and small letters both count as correct.
Submit the flag on the portal AND upload the LTspice file (.asc) you used, named TeamID_octal_meter.asc, on the Round 2 upload form. A flag without your .asc, or one your .asc cannot produce, gets no points.
Unzip the whole folder first and open the template from the unzipped folder. Running the empty template gives a "No such node" error: put your circuit in first.
