HEX PAINTER   (150 points)   needs: your Q1 DAC (two copies)

An old oscilloscope artist left two strings of hex digits: x.hex says where the beam goes left-right and y.hex says up-down.

WHAT TO DO
Open hex_painter_template.asc. Put one copy of your Q1 DAC in each box and plot OUTY against OUTX. The beam writes two words. Flag = BV{TOPWORD_BOTTOMWORD} using capital letters and digits.

FILES
  x.hex
  y.hex
  hex_painter_template.asc
  x_d0.txt
  x_d1.txt
  x_d2.txt
  x_d3.txt
  y_d0.txt
  y_d1.txt
  y_d2.txt
  y_d3.txt

Flags look like BV{...}. Capital and small letters both count as correct.
Submit the flag on the portal AND upload the LTspice file (.asc) you used, named TeamID_hex_painter.asc, on the Round 2 upload form. A flag without your .asc, or one your .asc cannot produce, gets no points.
Unzip the whole folder first and open the template from the unzipped folder.
