BACKWARDS   (75 points)   needs: Audacity only

An intercepted voice note sounds like an alien language.

WHAT TO DO
Make voice.wav understandable and write down the flag it spells.

FILES
  voice.wav

Flags look like BV{...}. Capital and small letters both count as correct.
Submit the flag on the portal.
